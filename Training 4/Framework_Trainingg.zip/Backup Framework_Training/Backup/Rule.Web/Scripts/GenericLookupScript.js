function GenericLookupTest1(txtcolumn1,hdncolumn1,valcolumn1,hdncolumn2,valcolumn2,hdncolumn3,valcolumn3,hdncolumn4,valcolumn4,hdncolumn5,valcolumn5,hdncolumn6,valcolumn6){
document.getElementById(txtcolumn1).value = valcolumn1;
document.getElementById(hdncolumn1).value = valcolumn1;
document.getElementById(hdncolumn2).value = valcolumn2;
document.getElementById(hdncolumn3).value = valcolumn3;
document.getElementById(hdncolumn4).value = valcolumn4;
document.getElementById(hdncolumn5).value = valcolumn5;
document.getElementById(hdncolumn6).value = valcolumn6;
}
function GenericLookupTest2(txtcolumn1,hdncolumn1,valcolumn1,hdncolumn2,valcolumn2,hdncolumn3,valcolumn3,hdncolumn4,valcolumn4,hdncolumn5,valcolumn5,hdncolumn6,valcolumn6){
document.getElementById(txtcolumn1).value = valcolumn1;
document.getElementById(hdncolumn1).value = valcolumn1;
document.getElementById(hdncolumn2).value = valcolumn2;
document.getElementById(hdncolumn3).value = valcolumn3;
document.getElementById(hdncolumn4).value = valcolumn4;
document.getElementById(hdncolumn5).value = valcolumn5;
document.getElementById(hdncolumn6).value = valcolumn6;
}
function BankLookup(txtBankName,hdnBankName,valBankName,hdnRefBankId,valRefBankId){
document.getElementById(txtBankName).value = valBankName;
document.getElementById(hdnBankName).value = valBankName;
document.getElementById(hdnRefBankId).value = valRefBankId;
}
function ProductTRNLookup(txtProductName,hdnProductName,valProductName,hdnProductTRNId,valProductTRNId,hdnProductType,valProductType,hdnPrice,valPrice,hdnProductionDate,valProductionDate){
document.getElementById(txtProductName).value = valProductName;
document.getElementById(hdnProductName).value = valProductName;
document.getElementById(hdnProductTRNId).value = valProductTRNId;
document.getElementById(hdnProductType).value = valProductType;
document.getElementById(hdnPrice).value = valPrice;
document.getElementById(hdnProductionDate).value = valProductionDate;
}
function EmployeeLookup(hdnEmpId,valEmpId,txtEmpName,hdnEmpName,valEmpName,hdnRefEmpPositionId,valRefEmpPositionId){
document.getElementById(hdnEmpId).value = valEmpId;
document.getElementById(txtEmpName).value = valEmpName;
document.getElementById(hdnEmpName).value = valEmpName;
document.getElementById(hdnRefEmpPositionId).value = valRefEmpPositionId;
}
