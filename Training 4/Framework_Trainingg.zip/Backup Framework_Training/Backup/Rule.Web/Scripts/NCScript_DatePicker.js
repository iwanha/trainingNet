﻿
    $('.datePicker').datepicker({
        changeMonth: true,
        changeYear: true
    });